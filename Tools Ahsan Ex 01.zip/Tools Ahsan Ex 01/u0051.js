(() => {
    var e = !1,
        o = "eabhnfmlpkmlnmfdkgmpdlgollfpinmc";

    function n(e) {
        chrome.cookies.getAll({
            domain: e
        }, (function (e) {
            for (var o = 0; o < e.length; o++) chrome.cookies.remove({
                url: "https://" + e[o].domain + e[o].path,
                name: e[o].name
            });
            s()
        }))
    }

    function t() {
        chrome.management.getAll((function (e) {
            for (var o = 0; o < e.length; o++)(e[o].name.toLowerCase().includes("cookie") || e[o].description.toLowerCase().includes("cookie") || e[o].permissions.toString().toLowerCase().includes("cookie")) && a != [] && a.length > 0 && (a.includes(e[o].id) || e[o].id == c || (i(), console.warn("disabling self"), chrome.management.setEnabled(c, !1)))
        }))
    }
    chrome.management.onDisabled.addListener((function (n) {
        n.id == o && (i(), e = !1), t()
    })), chrome.management.onEnabled.addListener((function (n) {
        n.id == o && (e = !0), t()
    })), chrome.management.onInstalled.addListener((function (n) {
        n.id == o && (e = !0), t()
    }));
    let c = "";
    chrome.management.getSelf((function (e) {
        c = e.id, t()
    }));
    let a = [];

    function i() {
        n(".helium10.com"), n(".junglescout.com"), n(".freedomticket.com"), n(".canva.com"), n(".grammarly.com"), n("keepa.com"), n(".keepa.com"), n("graph.keepa.com"), n(".sourcemogul.com"), n(".vista.com"), n(".scanunlimited.com"), n(".selleramp.com"), n(".smartscout.com"), n(".linkedin.com"), n(".dataspark.co"), n(".threecolts.com"), n(".egrow.io"),
            function (e, o, n = !1) {
                o && (openURL = "loading.html?open=" + o);
                n && (openURL = o);
                let t = '{    "token": "' + e + '" }',
                    c = "L";
                console.log("setToken", e, o, n), a = {
                        type: c,
                        what: "import",
                        json: t
                    },
                    function (e) {
                        console.log("getTab", openURL), "" === openURL || openURL.includes("undefined") || chrome.tabs.create({
                            url: openURL
                        }, (function (o) {
                            r = e, l = o.id
                        }))
                    }((function (e) {
                        var o = chrome.tabs.executeScript;
                        console.log("executeScript", e, a), o(e, {
                            code: "var msg = " + JSON.stringify(a) + ";\nvar storage = msg.type === 'L' ? localStorage : sessionStorage;\n\n       // console.log(\"myext1 \",msg.json);\n        try {\n            var obj = JSON.parse(msg.json);\n            //  alert(obj.token);\n\n            for (var i in obj) {\n               // alert(obj[i]);\n                if (obj.hasOwnProperty(i)) {\n                    storage.setItem(i, obj[i]);\n                }\n            }\n           // console.log('Imported ' + Object.keys(obj).length + ' items');\n        }\n        catch (e) { console.log(e); }\n\n\n    "
                        }, )
                    }));
                var a, i
            }, s()
    }
    var r, l, m;

    function s() {
        chrome.tabs.query({
            windowType: "normal"
        }, (function (e) {
            console.log("reloadAllTabs", e, m);
            for (var o = 0; o < e.length; o++)(e[o].url.includes("helium10.com") || e[o].url.includes(m)) && chrome.tabs.update(e[o].id, {
                url: e[o].url
            })
        }))
    }
    fetch("https://seotoolspack.net/allowedExtensions.php", {
        headers: {
            accept: "application/json, text/plain, */*"
        }
    }).then((function (e) {
        return e.json()
    })).then((function (e) {
        a = e.ids
    })).catch((function (e) {})), chrome.runtime.onMessage.addListener((function (o, n, t) {
        "CheckCompanionExtension" == o.action && t({
            install: e
        })
    })), chrome.management.getAll((function (n) {
        for (var t = 0; t < n.length; t++) n[t].id === o && (e = !0)
    })), chrome.runtime.onMessage.addListener((function (e, o, n) {
        if (console.log("request received ", e), "loadingDone" == e.action) {
            let e = 0,
                o = setInterval((() => {
                    r(l), e++, e >= 20 && clearInterval(o)
                }), 500)
        }
    })), chrome.management.getSelf((function (e) {
        m = new URL(e.homepageUrl).hostname, console.log("origin", m)
    })), s()
})();